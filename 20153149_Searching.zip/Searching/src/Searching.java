//package com.tutorialspoint;

import java.util.Arrays;

public class Searching {
 
   public static void main(String[] args) {

   // initializing unsorted int array
   int arr[] = {30,20,5,12,55};

   // sorting array
   Arrays.sort(arr);


   // entering the value to be searched
   int val = 12;

   int retVal = Arrays.binarySearch(arr,val);
   for (int num: arr){
	   System.out.print(num+" ");
   }
   System.out.println();
   System.out.println("The index of element 12 is : " + retVal);
   }
}